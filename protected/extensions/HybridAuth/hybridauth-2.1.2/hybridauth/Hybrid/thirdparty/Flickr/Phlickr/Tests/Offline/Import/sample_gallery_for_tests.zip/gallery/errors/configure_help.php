<?php /* $Id: configure_help.php,v 1.8 2004/06/09 11:35:48 jenst Exp $ */ ?>
<?php echo sprintf(_("If you experience problems, you can find help on the %sGallery Help Page%s."),
'<a href="http://gallery.sourceforge.net/help.php">', '</a>') ?>
