<?php /* $Id: configure_help.php,v 1.1 2005/06/30 11:16:56 jenst Exp $ */ ?>
<?php echo sprintf(_("If you experience problems, you can find help on the %sGallery Help Page%s."),
'<a href="http://gallery.sourceforge.net/help.php">', '</a>') ?>
