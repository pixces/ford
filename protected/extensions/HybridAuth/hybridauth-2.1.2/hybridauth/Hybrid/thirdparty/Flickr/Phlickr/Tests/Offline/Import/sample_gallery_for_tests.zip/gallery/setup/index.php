<?php
/*
 * Gallery - a web based photo album viewer and editor
 * Copyright (C) 2000-2005 Bharat Mediratta
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street - Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * $Id: index.php,v 1.72.2.3 2005/09/12 22:41:29 dmolavi Exp $
 */
?>
<?php
    /**
     * @package setup
     */
?>
<?php 
	/* 
	** Its important to have this as first position.
	** Otherwise constants are not defined.
	*/
	require (dirname(__FILE__) . '/init.php');
	
	require (dirname(__FILE__) . '/config_data.inc');
	require (GALLERY_BASE . '/js/sectionTabs.js.php');

	list($preserve, $go_next, $go_back, $next_page, $back_page, $this_page, $go_defaults, $refresh) =
	  getRequestVar(array('preserve', 'go_next', 'go_back', 'next_page', 'back_page', 'this_page', 'go_defaults', 'refresh'));

?>
<?php doctype(); ?>
<html>
<head>
	<title><?php echo _("Gallery Configuration") ?></title>
	<?php common_header(); ?>

	<script language="JavaScript" type="text/javascript">
        <!--

	function localGetElementsByTagName(tagName) {
		var eleArray;
		if (window.opera) eleArray = document.body.getElementsByTagName(tagName);
		else if (document.getElementsByTagName) eleArray = document.getElementsByTagName(tagName);
		else if (document.all) eleArray = document.all.tags(tagName);
		else if (document.layers) {
			eleArray = new Array();
			nnGetAllLayers(window, eleArray, 0);
		}
		return eleArray;
	}

	function nnGetAllLayers(parent, layerArray, nextIndex) {
		var i, layer;
		for (i = 0; i < parent.document.layers.length; i++) {
			layer = parent.document.layers[i];
			layerArray[nextIndex++] = layer;
			if (layer.document.layers.length) nextIndex = nnGetAllLayers(layer, layerArray, nextIndex);
		}
		return nextIndex;
	}

	function enableButtons() {
		var buttons = localGetElementsByTagName("input");

		var i = 0;
		while (buttons[i]) {
			if (buttons[i].type == "submit" || buttons[i].type == "button") {
				buttons[i].disabled = false;
			}
			i++;
		}
	}

	-->
	</script>

</head>

<body dir="<?php echo $gallery->direction ?>" onload="enableButtons()">
<?php
// Require a user to be logged in before allowing them to configure the server.
// If Gallery has not been configured before, allow to continue without logging in
configLogin(basename(__FILE__));


if (isset($go_defaults) || isset($refresh)) {
	$setup_page = $this_page;
} else if (isset($go_next)) {
	$setup_page = $next_page;
} else if (isset($go_back)) {
	$setup_page = $back_page;
}	

/* Array-ize the preserve list */
if (!empty($preserve)) {
	$tmp = explode(" ", urldecode($preserve));
	$preserve = array();
	foreach ($tmp as $key) {
		$preserve[$key] = 1;
		if (($gallery->session->configForm->$key = getRequestVar($key)) === NULL) {
			$gallery->session->configForm->$key = "";
			continue;
		}
	}
        $preserve = array();
} else {
	$preserve = array();
}

/* Cache passwords in order to prevent them from being erased.
 * Otherwise, we'll lose the passwords if someone revisits Step 2
 * and forgets to re-enter them. */
if (isset($gallery->session->configForm->editPassword) && (!empty($gallery->session->configForm->editPassword[0]) || !empty($gallery->session->configForm->editPassword[1]))) {
	$gallery->session->configForm->editPassword[2] = $gallery->session->configForm->editPassword[0];
	$gallery->session->configForm->editPassword[3] = $gallery->session->configForm->editPassword[1];
	$_REQUEST['editPassword'] = $gallery->session->configForm->editPassword;
}
if (isset($gallery->session->configForm->smtpPassword) && (!empty($gallery->session->configForm->smtpPassword[0]) || !empty($gallery->session->configForm->smtpPassword[1]))) {
	$gallery->session->configForm->smtpPassword[2] = $gallery->session->configForm->smtpPassword[0];
	$gallery->session->configForm->smtpPassword[3] = $gallery->session->configForm->smtpPassword[1];
	$_REQUEST['smtpPassword'] = $gallery->session->configForm->smtpPassword;
}

?>

<form method="post" action="index.php" name="config" enctype="application/x-www-form-urlencoded">
<?php
if (!isset($setup_page)) {
	$setup_page = "check";
}

$legit = array("check", "constants", "defaults", "confirm", "write");
if (in_array($setup_page, $legit)) {
	include(dirname(__FILE__) ."/$setup_page.inc");
} else {
	print _("Security violation") .".\n";
	exit;
}
?>

<?php

function embed_hidden($key) {
	global $$key;

	$buf = "";
	$real = $$key;

	if (is_array($real)) {
		foreach ($real as $real_key => $value) {
			if (is_array($value)) {
				foreach($value as $sub_key => $sub_value) {
					$name = stripWQuotesON($key . "[$real_key][$sub_key]");
					$buf .= '<input type="hidden" name="'. $name .'" value="';
					$buf .= urlencode($sub_value);
					$buf .= "\">\n";
				}
			} else {
				$name = stripWQuotesON("$key" . "[$real_key]");
				$buf .= '<input type="hidden" name="'. $name .'" value="';
				$buf .= urlencode($value);
				$buf .= "\">\n";
			}
		}
	} else {
		$buf .= '<input type="hidden" name="'. stripWQuotesON($key) . '" value="';
		$buf .= urlencode($real);
		$buf .= "\">\n";
	}
	return $buf;
}

foreach ($preserve as $key => $val) {
	if ($key && !isset($onThisPage[$key])) {
		$gallery->session->configForm->$key = $$key;
	}
}

// String-ize preserve list
$preserve = join(" ", array_keys($preserve));
print embed_hidden("preserve");

?>

</form>
</body>
</html>
