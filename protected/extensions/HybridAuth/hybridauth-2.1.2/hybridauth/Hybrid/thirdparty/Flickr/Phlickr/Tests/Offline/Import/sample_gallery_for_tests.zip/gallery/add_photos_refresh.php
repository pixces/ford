<html>
<head>
<title>Refresh</title>
</head>
<body onLoad="parent.opener.hideProgressAndReload(); window.close();">
<!-- This is a hack that's needed for the GR applet to be able to
refresh the album page after a successful upload... -->
</body>
</html>